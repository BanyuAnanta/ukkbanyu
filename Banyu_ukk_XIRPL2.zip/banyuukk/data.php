<?php
include("koneksi.php");
$result = mysqli_query($koneksi, "SELECT * FROM pinjaman");
?>

<h2>Daftar Pinjaman</h2>
<style>
    /* Reset some default styling */
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    /* Body Styles */
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background-color: #f4f6f9;
        color: #333;
        padding: 20px;
    }

    h2 {
        text-align: center;
        color: #333;
        margin-bottom: 30px;
    }

    /* Table Styling */
    table {
        width: 100%;
        border-collapse: collapse;
        margin: 0 auto;
        background-color: #ffffff;
        border-radius: 8px;
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
    }

    th,
    td {
        padding: 12px 16px;
        text-align: center;
        border: 1px solid #ddd;
    }

    th {
        background-color: #2c3e50;
        color: white;
        font-size: 16px;
    }

    td {
        background-color: #fff;
        font-size: 14px;
    }

    /* Action link */
    a {
        text-decoration: none;
        padding: 6px 12px;
        background-color: #3498db;
        color: white;
        border-radius: 4px;
        font-size: 14px;
        font-weight: bold;
        transition: background-color 0.3s ease;
    }

    a:hover {
        background-color: #2980b9;
    }

    /* No return date (empty) styling */
    td:last-child {
        color: #e74c3c;
    }

    /* Responsive Design */
    @media (max-width: 768px) {
        table {
            font-size: 12px;
        }

        th,
        td {
            padding: 8px;
        }

        a {
            font-size: 12px;
            padding: 8px 14px;
        }
    }
</style>

<table border="1" cellpadding="8">
    <tr>
        <th>ID</th>
        <th>Nama Peminjam</th>
        <th>No Buku</th>
        <th>Tanggal Pinjam</th>
        <th>Tanggal Kembali</th>
        <th>Aksi</th>
    </tr>
    <?php while ($row = mysqli_fetch_assoc($result)) { ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= $row['nama_peminjam'] ?></td>
            <td><?= $row['no_buku'] ?></td>
            <td><?= $row['tanggal_pinjam'] ?></td>
            <td><?= $row['tanggal_kembali'] ?? '-' ?></td>
            <td>
                <?php if (!$row['tanggal_kembali']) { ?>
                    <a href="kembali.php?id=<?= $row['id'] ?>">Tandai Kembali</a>
                <?php } else {
                    echo "Selesai";
                } ?>
            </td>
        </tr>
    <?php } ?>
</table>