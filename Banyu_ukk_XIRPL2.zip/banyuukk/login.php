<?php
session_start();
include('koneksi.php');

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM user WHERE username='$username' AND password='$password'";
    $result = mysqli_query($koneksi, $sql);

    if ($result->num_rows > 0) {
        $data = mysqli_fetch_assoc($result);

        if ($data['role'] == 'user') {
            header('location: pinjaman.php');
        } else if ($data['role'] == 'admin') {
            header('location: pendataan.php');
        } else {
            header('location: pendataan.php');
        }
    } else {
        echo 'LOGIN GAGAL';
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOGIN</title>
</head>
<style>
    /* Global Styles */
body {
    font-family: 'Arial', sans-serif;
    background-color: #f5f5f5;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    color: #333;
}

/* Centered form container */
.container {
    background-color: #ffffff;
    border-radius: 8px;
    padding: 30px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    width: 100%;
    max-width: 400px;
    text-align: center;
}

/* Title Style */
h1 {
    font-size: 24px;
    color: #333;
    margin-bottom: 20px;
}

/* Form inputs */
input[type="text"],
input[type="password"] {
    width: 100%;
    padding: 12px;
    margin: 10px 0;
    border: 2px solid #ccc;
    border-radius: 6px;
    box-sizing: border-box;
    font-size: 16px;
}

input[type="text"]:focus,
input[type="password"]:focus {
    border-color: #4CAF50;
    outline: none;
}

/* Submit button */
input[type="submit"] {
    width: 100%;
    padding: 12px;
    border: none;
    background-color: #4CAF50;
    color: white;
    border-radius: 6px;
    font-size: 16px;
    cursor: pointer;
}

input[type="submit"]:hover {
    background-color: #45a049;
}

/* Link to Registration */
a {
    display: block;
    margin-top: 15px;
    color: #4CAF50;
    text-decoration: none;
    font-size: 16px;
}

a:hover {
    text-decoration: underline;
}

/* Responsive Design */
@media (max-width: 480px) {
    .container {
        width: 90%;
        padding: 20px;
    }

    h1 {
        font-size: 20px;
    }
}


</style>

<body>
    <div>
        <form action="login.php" method="post">
            <input type="text" name="username" placeholder="username" required>
            <input type="password" name="password" placeholder="password" required>
            <input type="submit" name="login" value="login">
        </form>
        <a href="registrasi.php">Daftar</a>
    </div>
</body>

</html>