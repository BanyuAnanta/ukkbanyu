<?php
include "koneksi.php";

if (isset($_POST['submit'])) {
    $nama = $_POST['nama'];
    $no_buku = $_POST['no_buku'];
    $tanggal = date("Y-m-d");

    // Cek stok
    $stok = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT stok FROM buku WHERE no_buku = $no_buku"))['stok'];
    if ($stok > 0) {
        mysqli_query($koneksi, "INSERT INTO pinjaman (nama_peminjam, no_buku, tanggal_pinjam) VALUES ('$nama', $no_buku, '$tanggal')");
        mysqli_query($koneksi, "UPDATE buku SET stok = stok - 1 WHERE no_buku = $no_buku");
        echo "<script>alert('Peminjaman berhasil!'); window.location='pinjam.php';</script>";
    } else {
        echo "<script>alert('Stok buku habis!');</script>";
    }
    header('location: back1.php');
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Pinjam Buku</title>
    <style>
        /* Basic reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Body Styles */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f6f9;
            color: #333;
            padding: 20px;
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 30px;
        }

        /* Container for the form */
        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        /* Form Styling */
        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 8px;
            font-size: 14px;
            font-weight: bold;
        }

        input[type="text"],
        select {
            padding: 12px;
            font-size: 14px;
            border: 1px solid #ddd;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        button {
            padding: 12px 20px;
            font-size: 14px;
            font-weight: bold;
            color: white;
            background-color: #27ae60;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #2ecc71;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .container {
                padding: 20px;
            }

            input[type="text"],
            select {
                font-size: 12px;
                padding: 10px;
            }

            button {
                font-size: 12px;
                padding: 10px 18px;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>Form Peminjaman Buku</h2>
        <form method="post">
            Nama Peminjam: <input type="text" name="nama" required><br><br>
            Pilih Buku:
            <select name="no_buku" required>
                <option value="">-- Pilih --</option>
                <?php
                $buku = mysqli_query($koneksi, "SELECT no_buku, judul_buku, stok FROM buku");
                while ($row = mysqli_fetch_assoc($buku)) {
                    echo "<option value='{$row['no_buku']}'>{$row['judul_buku']} (Stok: {$row['stok']})</option>";
                }
                ?>
            </select><br><br>
            <button type="submit" name="submit">Pinjam</button>
        </form>
    </div>
</body>

</html>