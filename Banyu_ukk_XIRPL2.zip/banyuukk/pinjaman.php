<?php
session_start();
include('koneksi.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    /* Basic reset */
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    /* Body Styles */
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background-color: #f4f6f9;
        color: #333;
        padding: 20px;
    }

    h2 {
        text-align: center;
        color: #333;
        margin-bottom: 30px;
    }

    /* Table Styling */
    table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 40px;
    }

    th,
    td {
        padding: 12px;
        text-align: center;
        border: 1px solid #ddd;
    }

    th {
        background-color: #2c3e50;
        color: white;
        font-size: 16px;
    }

    td {
        background-color: #fff;
        font-size: 14px;
    }

    /* Image Styling */
    td img {
        width: 80px;
        height: auto;
        border-radius: 8px;
    }

    /* Action Buttons Styling */
    .action-buttons {
        display: flex;
        justify-content: center;
        gap: 10px;
    }

    .borrow-btn,
    .return-btn {
        padding: 8px 15px;
        text-decoration: none;
        border-radius: 4px;
        font-size: 14px;
        font-weight: bold;
        color: #fff;
        text-align: center;
    }

    .borrow-btn {
        background-color: #27ae60;
        transition: background-color 0.3s ease;
    }

    .return-btn {
        background-color: #e74c3c;
        transition: background-color 0.3s ease;
    }

    .borrow-btn:hover {
        background-color: #2ecc71;
    }

    .return-btn:hover {
        background-color: #c0392b;
    }

    /* Responsive Design */
    @media (max-width: 768px) {
        table {
            font-size: 12px;
        }

        th,
        td {
            padding: 8px;
        }

        .action-buttons {
            flex-direction: column;
            gap: 5px;
        }
    }
</style>

<body>
    <h2>DAFTAR PINJAMAN</h2>
    <table border="1">
        <tr>
            <th>KODE BUKU</th>
            <th>NO BUKU</th>
            <th>JUDUL BUKU</th>
            <th>TAHUN TERBIT</th>
            <th>STOK</th>
            <th>NAMA PENULIS</th>
            <th>PENERBIT</th>
            <th>JUMLAH HALAMAN</th>
            <th>HARGA</th>
            <th>GAMBAR</th>
        </tr>


        <?php
        $sql = mysqli_query($koneksi, "SELECT * FROM buku");
        while ($data = mysqli_fetch_array($sql)) {

        ?>
            <tr>
                <td><?= $data['kode_buku'] ?></td>
                <td><?= $data['no_buku'] ?></td>
                <td><?= $data['judul_buku'] ?></td>
                <td><?= $data['tahun_terbit'] ?></td>
                <td><?= $data['stok'] ?></td>
                <td><?= $data['penulis'] ?></td>
                <td><?= $data['penerbit'] ?></td>
                <td><?= $data['jumlah_halaman'] ?></td>
                <td><?= $data['harga'] ?></td>
                <td>
                    <img src="<?= $data['gambar_buku'] ?> " alt="cover" width="80px">
                </td>
                <td class="action-buttons">
                    <a href="pinjam.php?kode_buku=<?= urlencode($data['kode_buku']) ?>" class="borrow-btn">Pinjam</a>
                    <a href="kembalikan.php?kode_buku=<?= urlencode($data['kode_buku']) ?>" class="return-btn">Kembalikan</a>
                </td>
            </tr>
        <?php
        }
        ?>
    </table>
</body>

</html>