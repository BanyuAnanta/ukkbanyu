<?php
session_start();
include('koneksi.php');


if (isset($_POST['register'])) {
    
    $nama     = $_POST['nama_lengkap'];
    $username = $_POST['username'];
    $password = $_POST['password'];


    $role = 'user';


    $sql = "INSERT INTO user (nama_lengkap, username, password, role) VALUES (?, ?, ?, ?)";
    $stmt = mysqli_prepare($koneksi, $sql);
    mysqli_stmt_bind_param($stmt, "ssss", $nama, $username, $password, $role);


    if (mysqli_stmt_execute($stmt)) {
        echo "Registrasi berhasil! <a href='login.php'>Login di sini</a>";
    } else {
        echo "Gagal registrasi: " . mysqli_error($koneksi);
    }


    mysqli_stmt_close($stmt);
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrasi Pengguna</title>
</head>
<style>
    /* Atur Font dan Warna Latar */
    body {
        font-family: 'Arial', sans-serif;
        background-color: #f0f0f0;
        margin: 0;
        padding: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }

    /* Container untuk Form */
    .container {
        background-color: white;
        border-radius: 8px;
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        padding: 40px;
        width: 100%;
        max-width: 400px;
        transition: transform 0.3s ease-in-out;
    }

    /* Menambahkan animasi ke container */
    .container:hover {
        transform: translateY(-5px);
    }

    /* Judul Form */
    h2 {
        text-align: center;
        font-size: 24px;
        color: #333;
        margin-bottom: 20px;
        font-weight: bold;
    }

    /* Label untuk Input */
    label {
        font-size: 14px;
        color: #333;
        font-weight: bold;
        margin-bottom: 5px;
        display: block;
    }

    /* Input Field */
    input[type="text"],
    input[type="password"] {
        width: 100%;
        padding: 10px;
        margin: 10px 0;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-size: 16px;
        background-color: #fafafa;
        box-sizing: border-box;
    }

    /* Mengatur Hover dan Fokus pada Input */
    input[type="text"]:focus,
    input[type="password"]:focus {
        border-color: #4CAF50;
        outline: none;
    }

    /* Tombol Submit */
    input[type="submit"] {
        width: 100%;
        padding: 12px;
        background-color: #4CAF50;
        color: white;
        border: none;
        border-radius: 5px;
        font-size: 18px;
        cursor: pointer;
        margin-top: 20px;
        transition: background-color 0.3s ease;
    }

    /* Hover pada Tombol */
    input[type="submit"]:hover {
        background-color: #45a049;
    }

    /* Link Login */
    a {
        text-align: center;
        display: block;
        margin-top: 15px;
        color: #007BFF;
        text-decoration: none;
        font-size: 14px;
    }

    a:hover {
        text-decoration: underline;
    }
</style>

<body>
    <div class="container">

        <h2>Form Registrasi Pengguna</h2>
        <form action="registrasi.php" method="POST">
            <label for="nama_lengkap">Nama Lengkap:</label><br>
            <input type="text" name="nama_lengkap" required><br><br>

            <label for="username">Username:</label><br>
            <input type="text" name="username" required><br><br>

            <label for="password">Password:</label><br>
            <input type="password" name="password" required><br><br>

            <input type="submit" name="register" value="Daftar">
        </form>
    </div>
</body>

</html>